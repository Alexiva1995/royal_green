@extends('layouts.email')


@section('content')

<h4 class="card-title">
    <strong>
        ¡¡FENOMENAL!!
    </strong>
</h4>

<small>
    <p class="card-text text-justify">
        Tus resultados son los que hablan y cada vida que logras impactar te acerca hacia tu siguiente nivel,
        mientras
        ayudas a otras personas a hacer lo mismo, ese es justo el camino que te lleva a ser un
        <strong>UPPER</strong>.
    </p>
</small>
@endsection
@push('quote')
De seguro que serás nuestro próximo UPPER, <br>
asi pues que sigamos
@endpush