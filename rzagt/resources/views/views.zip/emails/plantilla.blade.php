@extends('layouts.email')


@section('content')

<h4 class="card-title text-center">
    <strong>BIENVENIDO<br> HAS TOMADO UNA EXCELENTE DECISIÓN.</strong>
</h4>

@endsection