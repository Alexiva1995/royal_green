<div class="col-12 mt-5" id="servicios">
    <h2 class=" text-alt-blue">
        <strong>Conoces nuestra empresas aliadas:</strong>
    </h2>
    <div class="card-desk mt-3">
        <div class="col-12 bg-alt-orange p-1 linea1">
            <div class="col-12 linea2">
                <div class="row ">
                    <div class="col-12 col-sm-4 text-center">
                        <a href="https://myacademytrading.com/" target="_blank">
                        <img src="{{asset('assets/imgLanding/logo-my-academy-principal.png')}}" alt="" height="140"></a>
                    </div>
                    <div class="col-12 col-sm-4 text-center">
                        <a href="https://www.u-bot.trade" target="_blank"> <img src="{{asset('assets/imgLanding/logo-u-bot--principal.png')}}" alt="" height="140"></a>
                    </div>
                    <div class="col-12 col-sm-4 text-center">
                        <img src="{{asset('assets/imgLanding/logo-win-principal.png')}}" alt="" height="140">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>