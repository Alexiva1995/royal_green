<div class="col-12 mt-5" id="comofunciona">
    <h2 class="text-center text-alt-blue">
        <strong>Alianza</strong>
    </h2>
    <p class="text-alt-gray text-justify">
        Trabajar en equipo te lleva mucho más lejos de lo que puedes imaginar, esto es algo que hemos entendido en LEVEL
        UP y parte de lo que nos gusta generar en los lideres que conforman esta gran familia, así pues que por el
        camino hemos construido alianzas estratégicas con empresas que comparten filosofías bastante afines a la
        nuestra, siendo que se encuentran comprometidas con aportar valor al mundo y a las personas, y elevar los
        estándares de vida basados en modelos de negocio del Siglo XXI dentro del concepto de una Nueva Economía de
        todos y para todos, entendiendo que la economía es un eje transversal en la vida de toda persona, y que se trata
        de construir beneficios desde un Ganar – Ganar.
    </p>
</div>