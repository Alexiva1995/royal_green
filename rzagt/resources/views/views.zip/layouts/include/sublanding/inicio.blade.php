<div class="card mb-3 no-border bg-trans" style="height:400px">
    <div class="row no-gutters">
        <div class="col-md-12 d-flex align-items-center">
            <div class="card-body">
                <h1 class="text-alt-blue" style="font-weight: 900;">
                    <strong>Nuestra Especialidad</strong>
                </h1>
                <h3 style="color: #00646b; font-weight: 600;">
                    Es llevar tu vida y finanzas
                </h3>
                <h3 style="color: #002a38; font-weight: 700;">
                    AL SIGUIENTE NIVEL
                </h3>
                <a class="btn bg-alt-orange text-white" target="_blank" href="{{route('login')}}">
                    <strong>INICIA AHORA</strong>
                </a>
            </div>
        </div>
    </div>
</div>
