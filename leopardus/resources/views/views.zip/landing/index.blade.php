@extends('layouts.landing')

@section('content')
@if ($landing == 0)
    {{-- Seccion de Servicios --}}
    @include('landing.component.services')
    {{-- Seccion de Quienes somos --}}
    @include('landing.component.quienessomos')
    {{-- Seccion de Como Funciona --}}
    @include('landing.component.comofunciona')
    {{-- Seccion Como Participar --}}
    @include('landing.component.comoparticipar')
    {{-- Seccion Comunicate --}}
    @include('landing.component.comunicate')
@elseif($landing == 2)
@include('landing.component.faq')
@endif
@endsection