<div class="col-12 mt-5" id="comofunciona">
    <h2 class="text-center text-alt-blue">
        <strong>¿Cómo funciona?</strong>
    </h2>
    <h5 class="text-center text-alt-blue">
        La gestion del riesgo es nuestra <strong>prioridad</strong>
    </h5>
    <p class="text-alt-gray text-justify">
        <small>
            La tecnología desarrollada por E-crypto FX nos permite analizar la variación en tiempo real de todas las
            criptomonedas que conforman la bolsa de activos de los principales exchanges del mundo, operar en el mercado
            mediante el uso de avanzados algoritmos, cuando las oportunidades sean detectadas por nuestros sistemas.
            Después de años de investigación, hemos creado algoritmos que se optimizan automáticamente cada mes, con el
            fin de analizar la data más reciente para una adecuada toma de decisiones, teniendo en cuenta la disminución
            del riesgo como nuestro principal objetivo, esta experiencia nos permitido crear unos cursos con los
            conceptos suficientes para operar de manera óptima el mercado forex.
        </small>
        <small>
            <ul class="text-alt-gray text-justify list-orange">
                <li>
                    Seguimiento y análisis en tiempo real de las principales criptomonedas y su precio en distintas
                    divisas.
                </li>
                <li>
                    Algoritmos de IA desarrollados para scannear las mejores oportunidades.
                </li>
                <li>
                    Optimización y adaptación automática periódicamente de la plataforma.
                </li>
                <li>
                    Curso avanzado de inversión en el mercado crypto.
                </li>
            </ul>
        </small>
    </p>
    <h4 class="text-center text-alt-blue">
        <strong>Rentabilidad, Gestión del riesgo, Transparencia, educación.</strong>
    </h4>
    <p class="text-alt-gray text-justify">
        <small>
            Nuestro objetivo es maximizar la rentabilidad teniendo como premisa fundamental una rigurosa gestión del
            riesgo en nuestras operaciones, aprovechamos la ventaja competitiva que nos ofrece la tecnología Blockchain
            para brindar completa transparencia en todas y cada una de nuestras transacciones (garantizando mediante
            Smart Contracts el cumplimiento de cada uno de nuestros compromisos con los ususarios)
        </small>
        <small>
            <ul class="text-alt-gray text-justify list-orange">
                <li>
                    Rentabilidad: Duplica tu capital en un plazo máximo de 100 dias habiles.
                </li>
                <li>
                    Gestion del riesgo: Inveriones inteligentes mediante sistemas automatizados.
                </li>
                <li>
                    Transparencia: Retiros de utilidades basados en contratos inteligentes de la red de Ethereum.
                </li>
                <li>
                    Educacion: Conocimiento adecuado para operar óptimamente el mercado de criptos.
                </li>
            </ul>
        </small>
    </p>
</div>