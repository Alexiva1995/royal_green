<div class="row pt-4 pb-4">
    <div class="accordion col-12" id="accordionExample">
        @for ($i = 1; $i < 10; $i++) <div class="card mb-3 accordion-alt">
            <div class="card-header" id="heading{{$i}}">
                {{-- <h2 class="mb-0 "> --}}
                <button class="btn boxshadow col-12 text-alt-gray btn-active {{($i != 1) ? 'collapsed' : ''}}"
                    type="button" data-toggle="collapse" data-target="#collapse{{$i}}" aria-expanded="true"
                    aria-controls="collapse{{$i}}">
                    <strong>Collapsible Group Item {{$i}} </strong>
                    <h4 class="active">
                        <svg class="bi bi-plus" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M10 5.5a.5.5 0 01.5.5v4a.5.5 0 01-.5.5H6a.5.5 0 010-1h3.5V6a.5.5 0 01.5-.5z"
                                clip-rule="evenodd"></path>
                            <path fill-rule="evenodd"
                                d="M9.5 10a.5.5 0 01.5-.5h4a.5.5 0 010 1h-3.5V14a.5.5 0 01-1 0v-4z" clip-rule="evenodd">
                            </path>
                        </svg>
                    </h4>

                    <h4 class="inactive">
                        <svg class="bi bi-dash" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor"
                            xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" d="M5.5 10a.5.5 0 01.5-.5h8a.5.5 0 010 1H6a.5.5 0 01-.5-.5z"
                                clip-rule="evenodd"></path>
                        </svg>
                    </h4>
                </button>
                {{-- </h2> --}}
            </div>

            <div id="collapse{{$i}}" class="collapse {{($i == 1) ? 'show' : ''}}" aria-labelledby="heading{{$i}}"
                data-parent="#accordionExample">
                <div class="card-body text-alt-gray">
                    <small>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ea labore cumque praesentium facilis,
                        amet
                        aspernatur laudantium odio earum modi quidem eligendi voluptate itaque aperiam ipsam architecto
                        corporis molestiae vero veniam!
                    </small>
                </div>
            </div>
    </div>
    @endfor
</div>
</div>