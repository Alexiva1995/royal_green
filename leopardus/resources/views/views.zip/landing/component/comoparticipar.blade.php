<div class="col-12 mt-5" id="participar">
    <h2 class="text-alt-blue">
        <strong>¿Cómo puedo participar?</strong>
    </h2>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 mt-5 justify-content-center">
        <div class="col mb-4">
            <div class="card boxshadow rounded-alt h-100">
                <div class="box">
                    <img src="{{asset('assets/imgLanding/icono_crear_una_cuenta-09.svg')}}" alt="" height="100px">
                </div>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <strong>Crea una cuenta</strong>
                    </h5>
                    <small class="card-text text-alt-gray text-justify">
                        Llena el formulario de registro que nos permitirá agregarte a nuestra base de datos y darte
                        acceso a los beneficios del sistema E-cripto FX
                    </small>
                </div>
            </div>
        </div>
        <div class="col mb-4">
            <div class="card boxshadow rounded-alt h-100">
                <div class="box">
                    <img src="{{asset('assets/imgLanding/realiza_el_deposito-09.svg')}}" alt="" height="100px">
                </div>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <strong>Realiza el deposito</strong>
                    </h5>
                    <small class="card-text text-alt-gray text-justify">
                        Deposita los USD 55 para que puedas comprar tu curso de inversión en criptomonedas
                    </small>
                </div>
            </div>
        </div>
        <div class="col mb-4">
            <div class="card boxshadow rounded-alt h-100">
                <div class="box">
                    <img src="{{asset('assets/imgLanding/educate-09.svg')}}" alt="" height="100px">
                </div>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <strong>Edúcate</strong>
                    </h5>
                    <small class="card-text text-alt-gray text-justify">
                        Adquiere tu curso avanzado de inversión en el mercado cripto y operalo de manera optima.
                    </small>
                </div>
            </div>
        </div>
    </div>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 justify-content-center">
        <div class="col mb-4">
            <div class="card boxshadow rounded-alt h-100">
                <div class="box">
                    <img src="{{asset('assets/imgLanding/rentabilidad-09.svg')}}" alt="" height="100px">
                </div>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <strong>Empieza a obtener rentabilidad</strong>
                    </h5>
                    <small class="card-text text-alt-gray text-justify">
                        Activa tu binario, invitando a dos personas que quieran aprender como invertir en el mercado
                        cripto, de esta manera comenzaras a recibir diariamente tu liquidación hasta pasados 100 dias
                        hábiles, momento en el que abras doblado tu capital.
                    </small>
                </div>
            </div>
        </div>
        <div class="col mb-4">
            <div class="card boxshadow rounded-alt h-100">
                <div class="box">
                    <img src="{{asset('assets/imgLanding/acelera_tu_rendimiento-09.svg')}}" alt="" height="100px">
                </div>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <strong>Acelera tus rendimientos</strong>
                    </h5>
                    <small class="card-text text-alt-gray text-justify">
                        Crea una red binaria y cobra diariamente el 10% de tu pierna débil, acelerando de esta manera
                        las rentabilidades ofrecidas hasta doblar tu capital inicial.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>