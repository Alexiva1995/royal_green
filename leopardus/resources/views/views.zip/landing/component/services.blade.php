<div class="col-12 mt-5" id="servicios">
    <h2 class="text-center text-alt-blue">
        <strong>Servicios</strong>
    </h2>
    <div class="card-desk mt-3">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4">
            <div class="col mb-4">
                <div class="card bg-light boxshadow rounded-alt h-100">
                    <img src="{{asset('assets/imgLanding/icono_educacion-09.svg')}}" alt="" class="card-img-top" height="100px">
                    <div class="card-body">
                        <h5 class="card-title text-center">
                            <strong>Educación</strong>
                        </h5>
                        <small class="card-text text-alt-gray text-justify">
                            El equipo pone toda su experiencia a disposición en un completo curso avanzado que te permitirá operar óptimamente el mercado cripto.
                        </small>
                    </div>
                </div>
            </div>
            <div class="col mb-4">
                <div class="card bg-light boxshadow rounded-alt h-100">
                    <img src="{{asset('assets/imgLanding/icono_rentabilidad-09.svg')}}" alt="" class="card-img-top" height="100px">
                    <div class="card-body">
                        <h5 class="card-title text-center">
                            <strong>Rentabilidad</strong>
                        </h5>
                        <small class="card-text text-alt-gray text-justify">
                            Posibilidad de doblar tu capital en 100 dias hábiles.
                        </small>
                    </div>
                </div>
            </div>
            <div class="col mb-4">
                <div class="card bg-light boxshadow rounded-alt h-100">
                    <img src="{{asset('assets/imgLanding/icono_pago_diario-09.svg')}}" alt="" class="card-img-top" height="100px">
                    <div class="card-body">
                        <h5 class="card-title text-center">
                            <strong>Pago Diario</strong>
                        </h5>
                        <small class="card-text text-alt-gray text-justify">
                            La plataforma reparte diariamente la rentabilidad que le corresponde a cada usuario.
                        </small>
                    </div>
                </div>
            </div>
            <div class="col mb-4">
                <div class="card bg-light boxshadow rounded-alt h-100">
                    <img src="{{asset('assets/imgLanding/icono_blockchain-09.svg')}}" alt="" class="card-img-top" height="100px">
                    <div class="card-body">
                        <h5 class="card-title text-center">
                            <strong>BlockChain</strong>
                        </h5>
                        <small class="card-text text-alt-gray text-justify">
                            Toda la plataforma está integrada con Blockchain, mediante Smart contracts de la red de Ethereum.
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>