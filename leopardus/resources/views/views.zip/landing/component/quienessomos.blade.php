<div class="col-12 mt-5" id="quienessomos">
    <div class="card mb-3 no-border bg-trans">
        <div class="row no-gutters">
            <div class="col-md-6 d-flex justify-content-center">
                <img src="{{asset('assets/imgLanding/quienes_somos-09.svg')}}" class="card-img" alt="...">
            </div>
            <div class="col-md-6">
                <div class="card-body">
                    <h1 class="text-alt-blue text-center">
                        <strong style="font-size: 1.5em;">Quiénes Somos</strong>
                    </h1>
                    <small>
                        <p class="card-text text-alt-gray text-justify">
                            E-cripto FX es un ecosistema financiero de alta de tecnología con las capacidades y
                            habilidades suficientes para rentabilizar cryptoactivos en las diferentes bolsas de valores
                            del mundo y contamos con la experiencia adecuada para enseñarte a operar manualmente el
                            mercado cripto.
                        </p>
                        <p class="card-text text-alt-gray text-justify">
                            El equipo de desarrollo está conformado por trades, matemáticos y estadísticos quienes
                            lideran un equipo interdisciplinario de programadores con miras a crear sistemas de alta
                            tecnología que permitan aprovechar ineficiencias que se presentan esencialmente en el
                            mercado de las cryptomonedas.
                        </p>
                        <p class="card-text text-alt-gray text-justify">
                            Luego de varios años de estudio e investigación estamos en la capacidad de scannear todos
                            las criptomonedas de los principales exchanges del mundo, con en el fin de identificar
                            momentos en los que los precios de dichos activos presentan oportunidades de arbitrajes con
                            riesgos potencialmente bajos, dicha experiencia nos permite también generar conocimiento y
                            una guía lógica que te permitirá operar fácilmente el mercado crypto.
                        </p>
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>