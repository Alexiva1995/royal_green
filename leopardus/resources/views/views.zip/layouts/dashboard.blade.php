<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $settings->name }} - {{ $title }}</title>

    <!-- Styles -->
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.css" />
    {{-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-colvis-1.6.1/b-flash-1.6.1/b-html5-1.6.1/datatables.min.css"/> --}}
    {{-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-colvis-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.css"/> --}}
    {{-- <link rel="stylesheet" type="text/css" href="{{ asset('assets/datatables/datatables.min.css') }}">
    <link rel="stylesheet" type="text/css"
        href="{{ asset('assets/datatables/Buttons-1.5.1/css/buttons.dataTables.min.css') }}"> --}}

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css"
        integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" />
    <link href="{{ asset('assets/global/plugins/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/global/plugins/simple-line-icons/simple-line-icons.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/global/plugins/bootstrap/css/bootstrap1.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css') }}" rel="stylesheet" />
    <!-- END GLOBAL MANDATORY STYLES -->
    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <link href="{{ asset('assets/global/plugins/icheck/skins/all.css') }}" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS -->
    <!-- BEGIN THEME GLOBAL STYLES -->
    <link href="{{ asset('assets/global/css/components.min.css') }}" rel="stylesheet" id="style_components" />
    <link href="{{ asset('assets/global/css/plugins.min.css') }}" rel="stylesheet" />
    <!-- END THEME GLOBAL STYLES -->
    <!-- BEGIN THEME LAYOUT STYLES -->
    <link href="{{ asset('assets/css/layout.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/css/themes/default.min.css') }}" rel="stylesheet" id="style_color" />
    <link href="{{ asset('assets/css/custom.css') }}" rel="stylesheet" />
    {{-- <link href="{{ asset('assets/css/celest.css') }}" rel="stylesheet"/> --}}
    <link href="{{ asset('assets/css/new_desing_dashboard.css') }}" rel="stylesheet" />
    <!-- END THEME LAYOUT STYLES -->
    <link href="{{ asset('assets/css/style_tree_graphic.css') }}" rel="stylesheet" type="text/css" />
    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" />


    <!--DATATABLES-->
    <script src="{{ asset('assets/global/plugins/jquery.min.js') }}" type="text/javascript"></script>

    <!-- tag inputs css -->
    <link rel="stylesheet" href="{{asset('assets/tagsinputs/bootstrap-tagsinput.css')}}">
    {{-- sumernote --}}
    <link rel="stylesheet" href="{{ asset('assets/summernote-develop/dist/summernote.css')}}">
</head>

<body class="page-container-bg-solid page-header-fixed page-sidebar-closed-hide-logo">
    <!-- BEGIN HEADER -->
    @include('layouts.include.header')
    <!-- END HEADER -->
    <!-- BEGIN HEADER & CONTENT DIVIDER -->
    <div class="clearfix"> </div>
    <!-- END HEADER & CONTENT DIVIDER -->
    <!-- BEGIN CONTAINER -->
    <div class="page-container">
        <!-- BEGIN SIDEBAR -->
        @if(Auth::user()->rol_id == 0)
        @include('layouts.include.sidebar')
        @else
        @include('layouts.include.sidebar2')
        @endif
        <!-- END SIDEBAR -->
        <!-- BEGIN CONTENT -->
        <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY -->
            <div class="page-content row">
                <div class="new-page-head page-head">
                    <h2>
                        {{$title}}
                        <div class="link-register">
                            <small>
                                <a href="javascript:;" onclick="copyToClipboard('copy2')">
                                    <p id="copy2">
                                        {{route('autenticacion.new-register').'?referred_id='.Auth::user()->ID.'&lado=I'}}</p>
                                    <img src="{{asset('assets/img/Icono-Enlace.png')}}" alt="" height="25">
                                    <span>Izquierda</span>
                                </a>
                            </small>
                            <small>
                                <a href="javascript:;" onclick="copyToClipboard('copy1')">
                                    <p id="copy1">
                                        {{route('autenticacion.new-register').'?referred_id='.Auth::user()->ID.'&lado=D'}}</p>
                                    <img src="{{asset('assets/img/Icono-Enlace.png')}}" alt="" height="25">
                                    <span>Derecha</span>
                                </a>
                            </small>
                        </div>
                    </h2>
                </div>
                @yield('content')
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <!--[if lt IE 9]>
    <script src="{{ asset('assets/global/plugins/respond.min.js') }}"></script>
    <script src="{{ asset('assets/global/plugins/excanvas.min.js') }}"></script>
    <![endif]-->
    <!-- BEGIN CORE PLUGINS -->
    <script src="{{ asset('assets/global/plugins/jquery.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/global/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/global/plugins/js.cookie.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js') }}"
        type="text/javascript"></script>
    <script src="{{ asset('assets/global/plugins/jquery.blockui.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js') }}"
        type="text/javascript"></script>
    <!-- END CORE PLUGINS -->
    <!-- BEGIN THEME GLOBAL SCRIPTS -->
    <script src="{{ asset('assets/scripts/app.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('/assets/global/plugins/icheck/icheck.min.js') }}" type="text/javascript"></script>
    <!-- END THEME GLOBAL SCRIPTS -->
    <!-- BEGIN THEME LAYOUT SCRIPTS -->
    <script src="{{ asset('assets/scripts/layout.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/scripts/demo.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/scripts/quick-sidebar.min.js') }}" type="text/javascript"></script>
    <script src="{{ asset('assets/scripts/ui-buttons.min.js') }}" type="text/javascript"></script>
    <!-- END THEME LAYOUT SCRIPTS -->

    <!-- tagsinput js -->
    <script src="{{asset('assets/tagsinputs/bootstrap-tagsinput.js')}}" type="text/javascript"></script>
    <!--DATATABLES-->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script type="text/javascript"
        src="https://cdn.datatables.net/v/dt/jszip-2.5.0/dt-1.10.20/b-1.6.1/b-flash-1.6.1/b-html5-1.6.1/b-print-1.6.1/datatables.min.js">
    </script>
    {{-- <script type="text/javascript" language="javascript" src="{{ asset('assets/datatables/datatables.min.js') }}">
    </script>
    <script type="text/javascript" language="javascript"
        src="{{ asset('assets/datatables/Buttons-1.5.1/js/dataTables.buttons.min.js') }}"></script> --}}
    <!-- Summernote -->
    <script type="text/javascript" language="javascript"
        src="{{ asset('assets/summernote-develop/dist/summernote.js') }}"></script>
    <!-- reloj js -->
    <script type="text/javascript" src="{{ asset('assets/scripts/graficascustom.js') }}"></script>
    <script type="text/javascript">
        function copyToClipboard(element) {
            var aux = document.createElement("input");
            aux.setAttribute("value", document.getElementById(element).innerHTML.replace('&amp;', '&'));
            document.body.appendChild(aux);
            aux.select();
            document.execCommand("copy");
            document.body.removeChild(aux);
            alert('Link Copiado')
        }
    </script>
    <script>
        $(document).ready(function () {
            setInterval(muestraReloj, 1000);
        })
    </script>
</body>

</html>