  @guest

  @else
  @php
  $cliente = DB::table('settingcliente')->where('id', 1)->get();
  $letras = ['A', 'B', 'C', 'D', 'E', 'F'];
  @endphp
  <div class="page-sidebar-wrapper">
      <!-- BEGIN SIDEBAR -->
      <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
      <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
      <div class="page-sidebar navbar-collapse collapse">
          <!-- BEGIN SIDEBAR MENU -->
          <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
          <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
          <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
          <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
          <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
          <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->

          <ul class="page-sidebar-menu" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
              {{-- INICIO --}}
              <li class="nav-item">
                  <a href="{{url('admin')}}" class="nav-link nav-toggle">
                      <i class="icon-home"></i>
                      <span class="title">Inicio</span>
                  </a>
              </li>
              {{-- <li class="nav-item">
                  <a href="{{url('admin/updateall')}}" class="nav-link nav-toggle">
                      <i class="fas fa-sync"></i>
                      <span class="title">Actualizar</span>
                  </a>
              </li> --}}
              <li class="nav-item">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fas fa-user-plus"></i>
                    <span class="title">Registrar</span>
                    <span class="arrow"></span>
                    <ul class="sub-menu">
                        <li class="nav-item">
                            <a href="{{route('autenticacion.new-register').'?referred_id='.Auth::user()->ID.'&lado=D'}}"
                                class="nav-link">
                                <span class="title">Nuevo Usuario Derecha</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route('autenticacion.new-register').'?referred_id='.Auth::user()->ID.'&lado=I'}}"
                                class="nav-link">
                                <span class="title">Nuevo Usuario Izquierda</span>
                            </a>
                        </li>
                    </ul>
                </a>
            </li>
              @if ($cliente[0]->cliente == 1)
              <li class="nav-item">
                  <a href="{{url('autentication/register')}}?referred_id={{ Auth::user()->ID }}&tipouser=Cliente"
                      class="nav-link nav-toggle">
                      <i class="fas fa-user-plus"></i>
                      <span class="title">Nuevo Registro Cliente</span>
                  </a>
              </li>
              @endif
              {{-- FIN INICIO --}}
              {{-- GEONOLOGIA --}}
              <li class="nav-item">
                  <a href="javascript:;" class="nav-link nav-toggle">
                      <i class="fas fa-sitemap"></i>
                      <span class="title">Red de Usuarios</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub-menu">
                      <li class="nav-item">
                          <a href="{{url('referraltree')}}?" class="nav-link">
                              <span class="title">Árbol de Usuarios</span>
                          </a>
                      </li>
                      @if ($cliente[0]->cliente == 1)
                      <li class="nav-item">
                          <a href="{{url('referraltree')}}?user=Cliente" class="nav-link">
                              <span class="title">Árbol de Clientes</span>
                          </a>
                      </li>
                      @endif
                      <li class="nav-item">
                          <a href="{{url('admin/network/directrecords')}}" class="nav-link">
                              <span class="title">Registros Directos</span>
                          </a>
                      </li>
                      <li class="nav-item">
                          <a href="{{url('admin/network/networkrecords')}}" class="nav-link">
                              <span class="title">Registros en Red</span>
                          </a>
                      </li>
                  </ul>
              </li>
              {{-- Tablero --}}
              {{-- <li class="nav-item">
                  <a href="javascript:;" class="nav-link nav-toggle">
                      <i class="fas fa-sitemap"></i>
                      <span class="title">Tableros de Usuarios</span>
                      <span class="arrow"></span>
                  </a>
                  <ul class="sub-menu">
                      <li class="nav-item">
                          <a href="{{url('admin/fichas/')}}" class="nav-link">
              <span class="title">Asignar Fichas</span>
              </a>
              </li>
              @foreach ($letras as $letra)
              <li class="nav-item">
                  <a href="{{url('referraltree/tablero/'.$letra)}}" class="nav-link">
                      <span class="title">Tablero {{$letra}}</span>
                  </a>
              </li>
              @endforeach
          </ul>
          </li> --}}
          {{-- FIN GENEALOGIA --}}
          {{-- TRANSACCIONES --}}
          <li class="nav-item">
              <a href="javascript:;" class="nav-link nav-toggle">
                  <i class="far fa-money-bill-alt"></i>
                  <span class="title">Transacciones</span>
                  <span class="arrow"></span>
              </a>
              <ul class="sub-menu">
                  <li class="nav-item">
                      <a href="{{url('admin/transactions/networkorders')}}" class="nav-link">
                          <span class="title">Ordenes de Red</span>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="{{url('admin/transactions/personalorders')}}" class="nav-link">
                          <span class="title">Ordenes Personales</span>
                      </a>
                  </li>
              </ul>
          </li>
          {{--FIN TRANSACCIONES --}}
          {{--INICIO BILLETERA --}}
          <li class="nav-item">
              <a href="javascript:;" class="nav-link nav-toggle">
                  <i class="fas fa-wallet"></i>
                  <span class="title">Billetera</span>
                  <span class="arrow"></span>
              </a>
              <ul class="sub-menu">
                  <li class="nav-item">
                      <a href="{{url('admin/wallet/')}}" class="nav-link">
                          <span class="title">Mi Billetera Cash</span>
                      </a>
                  </li>
                  {{-- <li class="nav-item">
                      <a href="{{url('admin/wallet/tantechcoins')}}" class="nav-link">
                          <span class="title">Mi Billetera Tantech</span>
                      </a>
                  </li> --}}
                  <li class="nav-item">
                      <a href="{{url('admin/wallet/tantechcoinspersonal')}}" class="nav-link">
                          <span class="title">Mis Tantech Personales</span>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="{{url('admin/wallet/puntos')}}" class="nav-link">
                          <span class="title">Mi Billetera Puntos</span>
                      </a>
                  </li>
                  {{-- <li class="nav-item">
                          <a href="{{url('admin/wallet/historial')}}" class="nav-link">
                  <span class="title">Historial de Transferencias</span>
                  </a>
          </li> --}}
          <li class="nav-item">
              <a href="{{url('admin/wallet/cobros')}}" class="nav-link">
                  <span class="title">Retiros</span>
              </a>
          </li>
          </ul>
          </li>
          {{-- FIN BILLETERA --}}

          {{-- INFORMES --}}
          <li>
              <a href="javascript:;" class="nav-link nav-toggle">
                  <i class="fas fa-chart-bar"></i>
                  <span class="title">Informes</span>
                  <span class="arrow"></span>
                  <ul class="sub-menu">

                      <li class="nav-item">
                          <a href="{{url('admin/info/activacion')}}" class="nav-link">
                              <span class="title">Activacion</span>
                          </a>
                      </li>
                      <li class="nav-item">
                          <a href="{{url('admin/info/comisiones')}}" class="nav-link">
                              <span class="title">Comisiones</span>
                          </a>
                      </li>
                      <li class="nav-item">
                          <a href="{{url('admin/info/liquidacion')}}" class="nav-link">
                              <span class="title">Liquidaciones</span>
                          </a>
                      </li>
                      {{-- <li class="nav-item">
                              <a href="{{url('admin/info/repor-comi')}}" class="nav-link">
                      <span class="title">Reportes Comisiones</span>
              </a>
          </li> --}}
          </ul>
          </a>
          </li>

          {{-- FIN GESTION DE PERFILES --}}
          {{-- INICIO TICKETS --}}
          <li class="nav-item">
              <a href="javascript:;" class="nav-link nav-toggle">
                  <i class="fas fa-tag"></i>
                  <span class="title">Tickets</span>
                  <span class="arrow"></span>
              </a>
              <ul class="sub-menu">
                  <li class="nav-item">
                      <a href="{{url('admin/ticket/ticket')}}" class="nav-link">
                          <span class="title">Generar Tickets</span>
                      </a>
                  </li>
                  <li class="nav-item">
                      <a href="{{url('admin/ticket/misticket')}}" class="nav-link">
                          <span class="title">Mis Tickets</span>
                      </a>
                  </li>
                  {{-- <li class="nav-item">
                      <a href="{{url('admin/ticket/todosticket')}}" class="nav-link">
                          <span class="title">Todos Los Tickets</span>
                      </a>
                  </li> --}}
              </ul>
          </li>
          {{-- FIN TICKETS --}}

          {{-- INGRESOS DETALLADOS --}}
          {{-- <li class="nav-item">
                  <a href="{{url('admin/gestion/ingresos-detallado')}}" class="nav-link nav-toggle">
          <i class="far fa-list-alt"></i>
          <span class="title">Ingresos detallados</span>
          </a>
          </li> --}}
          {{--FIN INGRESOS DETALLADOS --}}

          {{-- RANKING --}}
          <li class="nav-item">
              <a href="{{url('admin/ranking')}}" class="nav-link nav-toggle">
                  <i class="fas fa-star"></i>
                  <span class="title">Ranking</span>
              </a>
          </li>
          {{--FIN RANKING --}}
          {{-- RANKING --}}
          <li class="nav-item">
              <a href="{{url('tienda')}}" class="nav-link nav-toggle">
                  <i class="far fa-gem"></i>
                  <span class="title">Tienda</span>
              </a>
          </li>
          {{--FIN RANKING --}}
          {{-- VISION DE USUARIO --}}
          {{-- <li>
              <a href="{{url('admin/buscar')}}" class="nav-link nav-toggle">
                  <i class="far fa-address-card"></i>
                  <span class="title">Visión de Usuario</span>
              </a>
          </li> --}}
          {{-- FIN VISION DE USUARIO --}}

          {{-- HERRAMIENTAS --}}
          <li>
              <a href="javascript:;" class="nav-link nav-toggle">
                  <i class="fas fa-wrench"></i>
                  <span class="title">Herramientas</span>
                  <span class="arrow"></span>
                  <ul class="sub-menu" style="display: none;">
                      <li class="nav-item">
                          <a href="{{url('admin/archivo/ver')}}" class="nav-link">
                              <span class="title">Documentos</span>
                          </a>
                      </li>

                      <li class="nav-item">
                          <a href="{{url('admin/archivo/contenido')}}" class="nav-link">
                              <span class="title">Noticias</span>
                          </a>
                      </li>
                  </ul>
              </a>
          </li>
          {{-- FIN HERRAMIENTAS --}}
        <li class="nav-item">
            <a href="{{ route('admin.user.edit') }}" class="nav-link nav-toggle">
                <i class="icon-settings"></i>
                <span class="title">Editar Perfil</span>
            </a>

        </li>

          {{-- CERRAR SESIÓN --}}
          <li class="nav-item">
              <a href="{{ route('logout') }}"
                  onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="nav-link">
                  <i class="fas fa-sign-out-alt"></i>
                  <span class="title">Cerrar Sesión</span>
              </a>
              <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                  {{ csrf_field() }}
              </form>
          </li>
          {{-- FIN CERRAR SESIÓN --}}



          </ul>
      </div>
  </div>
  @endguest