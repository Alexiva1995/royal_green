<div class="card mb-3 no-border bg-trans">
    <div class="row no-gutters">
        <div class="col-md-5">
            <img src="{{asset('assets/imgLanding/ethc_pagina_principal-12.svg')}}" class="card-img" alt="...">
        </div>
        <div class="col-md-6 d-flex align-items-center">
            <div class="card-body">
                <h3 class="text-alt-gray">
                    Somos <strong class="text-alt-orange">expertos</strong> en rentabilizar
                </h3>
                <h1 class="text-alt-blue">
                    <strong style="font-size: 1.3em">CRIPTOACTIVOS</strong>
                </h1>
                <h5>
                    <strong class="text-alt-gray">Democratización de la inversión en cryptos</strong>
                </h5>
                <p class="card-text text-alt-gray">
                    Sistema que permite doblar tu capital en un plazo máximo de 100 días hábiles,
                    inicia con nosotros accede a la plataforma y estés habilitado para comprar
                    tu info-producto de educación en trading
                </p>
            </div>
        </div>
    </div>
</div>
<div class="col-12 bg-alt-blue rounded-alt p-3">
    <div class="row">
        <div class="col-12 col-sm-4 text-center">
            <img src="{{asset('assets/imgLanding/logo_btc-10.svg')}}" alt="" height="40">
        </div>
        <div class="col-12 col-sm-4 text-center">
            <img src="{{asset('assets/imgLanding/logo_eth-10.svg')}}" alt="" height="40">
        </div>
        <div class="col-12 col-sm-4 text-center">
            <img src="{{asset('assets/imgLanding/logo_economista-10.svg')}}" alt="" height="40">
        </div>
    </div>
</div>