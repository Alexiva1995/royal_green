<div class="row pt-4 pb-4">
    <div class="col-6 col-sm-4 col-lg-3 d-flex align-items-start" style="position:sticky; top:100px">
        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link text-alt-blue {{($tipo == 'cookies') ? 'active' : ''}}" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home"
                role="tab" aria-controls="v-pills-home" aria-selected="true">Políticas de Cookies</a>
            <a class="nav-link text-alt-blue {{($tipo == 'documentacion') ? 'active' : ''}}" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile"
                role="tab" aria-controls="v-pills-profile" aria-selected="false">Documentación</a>
            <a class="nav-link text-alt-blue {{($tipo == 'avisolegal') ? 'active' : ''}}" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages"
                role="tab" aria-controls="v-pills-messages" aria-selected="false">Aviso Legal</a>
            <a class="nav-link text-alt-blue {{($tipo == 'privacidad') ? 'active' : ''}}" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings"
                role="tab" aria-controls="v-pills-settings" aria-selected="false">Privacidad</a>
        </div>
    </div>
    <div class="col-6 col-sm-8 col-lg-9">
        <div class="tab-content" id="v-pills-tabContent">
            <div class="tab-pane fade {{($tipo == 'cookies') ? 'show active' : ''}}" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                <h5 class="text-alt-gray">
                    <strong>Cookies</strong>
                </h5>
                <small class="text-justify text-alt-gray">
                    <p>
                        El titular de los datos deberá aceptar la instalación de Cookies en su navegador. Para más
                        información, puede consultar la Política de Cookies de E-Cripto FX.
                    </p>
                    <h6>Actualización de las políticas</h6>
                    <p>
                        Este documento es la versión del día 15 de noviembre de 2019. E-Cripto FX está en continua
                        evolución por eso es posible que a lo largo del tiempo modifiquemos la plataforma y sea
                        necesario modificar nuestras políticas y, en consecuencia, que debamos actualizar el Aviso
                        Legal. Por eso, el Aviso Legal, la Política de Privacidad, la Política de Cookies o la página
                        web, pueden ser actualizadas en cualquier momento y sin previo aviso y, cada vez que un usuario
                        acceda a E-Cripto FX, la nueva política regirá su uso y entrará en vigor tras la publicación. En
                        la medida de lo posible intentaremos avisar a los usuarios de los cambios, pero E-Cripto FX
                        sugiere que el usuario revise periódicamente las políticas. Si sigue utilizando E-Cripto FX una
                        vez publicadas las nuevas condiciones, el usuario aceptará y estará de acuerdo con todas las
                        modificaciones de esta política. Si se realizan cambios en este documento legal se modificará la
                        fecha del documento. Revisa la página web de E-Cripto FX para leer la última versión disponible.
                    </p>
                </small>
            </div>
            <div class="tab-pane fade {{($tipo == 'documentacion') ? 'show active' : ''}}" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                <div class="row row-cols-1 row-cols-md-3 justify-content-center">
                    <div class="col">
                        <div class="card text-white bg-secondary h-100 pt-5 pb-5 rounded-alt text-center">
                            <div class="card-body">
                                <h6 class="card-title">Propuesta Comercial</h6>
                                <a href="#" class="btn bg-alt-orange text-white">Descargar PDF</a>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card text-white bg-secondary h-100 pt-5 pb-5 rounded-alt text-center">
                            <div class="card-body">
                                <h6 class="card-title">Plan de Compensación</h6>
                                <a href="#" class="btn bg-alt-orange text-white">Descargar PDF</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade {{($tipo == 'avisolegal') ? 'show active' : ''}}" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                <h5 class="text-alt-gray">
                    <strong>Aviso Legal</strong>
                </h5>
                <small class="text-justify text-alt-gray">
                    <p>
                        AI acceder, visualizar, crear una cuenta, usar la plataforma y/o realizar una aportación en
                        E-Cripto
                        FX está aceptando las siguientes condiciones sin limitaciones ni excepciones. Si no acepta las
                        condiciones de este Aviso Legal, no deberá visualizar, ni darse de alta, ni realizar ninguna
                        aportación en E-Cripto FX. Usar cualquier funcionalidad de E-Cripto FX supondrá la aceptación de
                        este Aviso Legal y tendrá la misma validez que si hubiera firmado un contrato físicamente.
                        <br>
                        El sitio web de E-Cripto FX proporciona gran diversidad de información, servicios y datos. El
                        usuario asume su responsabilidad en el uso correcto del sitio web. Esta responsabilidad se
                        extenderá
                        a:
                        <ul class="text-alt-gray text-justify list-orange">
                            <li>
                                La veracidad y licitud de los datos aportados por el usuario en los formularios de
                                E-Cripto
                                FX para el acceso a ciertos contenidos o servicios ofrecidos por la web.
                            </li>
                            <li>
                                El uso de la información, servicios y datos ofrecidos por E-Cripto FX contrariamente o
                                contraviniendo a lo dispuesto por las presentes condiciones, la Iey, la moral, las
                                buenas
                                costumbres o el orden público, o que de cualquier otro modo puedan suponer lesión de los
                                derechos de terceros o del propio funcionamiento del sitio web.
                            </li>
                        </ul>
                    </p>
                    <h6>Condiciones iniciales</h6>
                    <p>
                        Queremos que nuestra plataforma sea lo más abierta posible, pero también queremos que sea segura
                        y
                        conforme a la Iey, por este motivo, si quieres formar parte de E-Cripto FX, es necesario que
                        aceptes
                        las siguientes restricciones básicas:
                        <ul class="text-alt-gray text-justify list-orange">
                            <li>
                                Debes tener al menos 18 años, o la edad mínima legal en tu país.
                            </li>
                            <li>
                                No debes haber sido inhabilitado anteriormente en una cuenta creada por ti en E-Cripto
                                FX a
                                causa de una infracción de cualquiera de nuestras políticas o de la Ley.
                            </li>
                        </ul>
                    </p>
                    <h6>La Plataforma</h6>
                    <p>
                        Las compras deben ser de USD 55 y se realizan en ethereum al monedero que indique la plataforma
                        y al
                        cambio entre el ethereum y el dólar en el momento de la compra. Cualquier depósito realizado por
                        debajo de este importe será rechazado por la plataforma. Asi mismo las compras que superen USD55
                        serán rechazadas por la plataforma.
                        <br>
                        Desde una misma cuenta en E-Cripto FX se puede realizar una única compra de producto.
                        <br>
                        Las compras y las valorizaciones se reflejan en la cuenta del usuario tanto en
                        Dólares como en ethereum.
                        <br>
                        Los pagos de las valorizaciones producto del bono binario se realizaran todos los días a las
                        23:59
                        (salvo fines de semana y festivos) hora de España y tendrá un fee del 15%
                        <br>
                        Los pagos de las valorizaciones diarias se realizan directamente en la billetera que cada
                        usuario haya adjuntado en el formulario de registro.
                    </p>
                    <h6>Comisiones</h6>
                    <p>
                        E- Cripto FX cobra un fee de entrada equivalente al 10% del valor del producto comprado es por
                        esto que el usuario debe pagar USD55 y un 15% del valor pagado diariamente por concepto de
                        valorización.
                    </p>
                    <h6>Asunción de riesgo</h6>
                    <p>
                        Recuerde que el mercado de Criptomonedas conlleva un alto nivel de riesgo y puede no ser
                        apropiado para determinadas personas. Invertir capital en el mercado cripto basado en los
                        conceptos aprendidos con los productos que E-Cripto FX ofrece es responsabilidad única del
                        usuario. Antes de realizar una inversión debe considerar cuidadosamente sus objetivos de
                        inversión, su nivel de experiencia y el riesgo que desea asumir. Cualquier tipo de inversión que
                        realice debe partir de la premisa de que nunca se debe invertir un capital que no pueda
                        permitirse perder. Siempre que se invierte en criptoactivos debemos ser conscientes de todos los
                        riesgos asociados a la inversión.
                    </p>
                    <h6>Contenido</h6>
                    <p>
                        Ningún contenido de este documento, del sitio web de E-Cripto FX o cualquier documentación de la
                        plataforma suponen una recomendación de inversión. La información no está dirigida a la
                        distribución o el uso por cualquier persona, en cualquier país o jurisdicción donde dicha
                        distribución o uso sean contrarios a las leyes o regulaciones locales.
                        Los conceptos del tipo "inversión", "fondo", "plan", "rentabilidad", "capital", “participación",
                        ”aportación", “interés", ”comisión”, ”interés compuesto”, o similares no suponen una declaración
                        de inversión ni conllevan un significado más allá del meramente informativo.
                    </p>
                    <h6>Garantías</h6>
                    <p>
                        El sitio web de E-Cripto FX y su contenido se proporcionan "tal cual". No se ofrece ninguna
                        garantía, explícita o implícita, en relación con cualquier contenido, el sitio web, la exactitud
                        de cualquier información o cualquier derecho o licencia bajo este acuerdo incluyendo, sin
                        limitación, cualquier garantía implícita de comerciabilidad o adecuación para un propósito
                        particular. E-Cripto FX no representa ni garantiza que el sitio web o su contenido cumplan con
                        sus requisitos o que su uso sea ininterrumpido o libre de errores. E-Cripto FX no será
                        responsable ante usted o cualquier otra persona o entidad por cualquier daño general, punitivo,
                        especial, indirecto, consecuente o incidental, o pérdida de beneficios o cualquier otro daño,
                        costo o pérdida que surja de su uso del sitio web o de su contenido.
                    </p>
                    <h6>Bono Binario</h6>
                    <p>
                        Si recomienda E-Cripto FX debe realizarlo conforme a la información aportada por E-Cripto FX y
                        en ningún caso debe recomendarlo usando información no veraz o exagerada.
                        <br>
                        Para que un referido quede vinculado con la cuenta del patrocinador, es necesario, que este se
                        registre en E-Cripto FX aportando el código de referido que vincula con la cuenta.
                        <br>
                        El”bono binario" supone el derecho a recibir hasta el 10%, luego de tener 2 referidos frontales,
                        del total de las ventas que el equipo menor haya realizado. La rentabilidad se cobra diariamente
                        en la billetera del usuario.
                    </p>
                    <h6>Uso de la plataforma</h6>
                    <p>
                        El usuario entiende y acepta que E-Cripto FX pueda divulgar sus comunicaciones y actividades en
                        E-Cripto FX en respuesta a peticiones legales por parte de autoridades gubernamentales,
                        incluidas las peticiones de la Iey patriótica norteamericana (U.S. Patriot Act), las órdenes
                        judiciales, garantías o citaciones o para proteger los derechos de E-Cripto FX. El usuario
                        acepta que, en el caso de que E-Cripto FX ejerza cualquiera de sus derechos aquí mencionados por
                        cualquier razón, E-Cripto FX no tendrá ninguna responsabilidad para con él.
                        <br>
                        El usuario defenderá y exonerará a E-Cripto FX, sus correspondientes empleados, contratistas,
                        agentes, sucesores y encargados y los compensará a la mayor brevedad por todas y cada una de las
                        pérdidas, reclamaciones, daños, liquidaciones, gastos, costos o responsabilidades de la
                        naturaleza que sea (incluidos honorarios razonables de los abogados) a los que las personas
                        citadas anteriormente puedan verse sujetas, o que estén derivados, basados, o sean consecuencia
                        o estén relacionados de alguna manera con el uso que usted haga de E-Cripto FX o con
                        reclamaciones de terceros por violación o incumplimiento de este aviso legal.
                        <br>
                        E-Cripto FX se reserva el derecho a supervisar, prohibir, restringir, bloquear, suspender,
                        finalizar, borrar o interrumpir el acceso a cualquier usuario, en cualquier momento, sin previo
                        aviso, sin necesidad de especificar ninguna razón por ello y a su criterio. E-Cripto FX podrá
                        eliminar, borrar, bloquear, filtrar o restringir material por cualquier otro medio y al propio
                        criterio de E-Cripto FX. Así mismo E-Cripto FX podrá interrumpir el servicio o resolver de modo
                        inmediato la relación con el usuario, sin previo aviso o responsabilidad, si detecta un uso de
                        su plataforma o de cualquiera de los servicios ofertados en la misma, contrario al presente
                        Aviso Legal. En este punto, su derecho de usar el Sitio Web cesará inmediatamente. Si se ha
                        realizado alguna compra y tiene activo el bono binario, este dejara de pagrse a partir de la
                        fecha de la sanción.
                        <br>
                        E-Cripto FX no controla la utilización que los usuarios hacen de la plataforma, ni garantiza que
                        lo hagan de forma conforme al presente Aviso Legal. E-Cripto FX se reserva el derecho de dejar
                        de prestar cualquiera de los servicios que integran la plataforma, bastando para ello
                        comunicarlo en la pantalla de acceso al servicio. Se reserva, asimismo, el derecho de modificar
                        unilateralmente, en cualquier momento y sin previo aviso, las condiciones de la plataforma, así
                        como los servicios y las Normas de Uso de la Plataforma requeridas para su utilización.
                    </p>
                    <h6>Seguridad y acceso</h6>
                    <p>
                        Cuando se crea una cuenta en E-Cripto FX el usuario debe introducir la contraseña de acceso que
                        desea utilizar. El usuario debe guardar y custodiar la clave de acceso facilitada y asume, por
                        tanto, cuantos daños y/o perjuicios de todo tipo se deriven del quebrantamiento o revelación de
                        dicha contraseña. El usuario se compromete a no facilitar a nadie los datos de acceso a su
                        cuenta. El usuario podrá en cualquier momento cambiar las contraseñas desde su panel de
                        administración
                        <br>
                        En caso de que el usuario olvide la clave podrá recuperarla en cualquier momento usando el email
                        con el que se registró al servicio. En caso de no tener acceso al email utilizado será imposible
                        recuperar las claves y por tanto el acceso a la cuenta.
                        <br>
                        Es responsabilidad del usuario tener acceso al email utilizado para registrarse a E-Cripto FX,
                        dado que todas las comunicaciones entre E-Cripto FX y el usuario se realizarán a través de esa
                        dirección de email.
                    </p>
                    <h6>Limitación de la responsabilidad</h6>
                    <p>
                        En el grado máximo permitido por Iey, E-Cripto FX y sus afiliadas, proveedores, socios y agentes
                        no tienen ningún tipo de obligación o responsabilidad en relación con todos aquellos daños y
                        perjuicios indirectos, incidentales, especiales, punitivos o consecuentes o con las
                        responsabilidades que se originen o se relacionen con el uso que usted haga de la plataforma o
                        servicio, o de algún contenido provisto por o a través de la plataforma o el servicio, aun
                        cuando hayamos sido informados acerca de la posibilidad de tales daños y perjuicios con
                        antelación. Esta limitación se aplica a los daños y perjuicios que se originan de:
                        <ul class="text-alt-gray text-justify list-orange">
                            <li>
                                su uso o imposibilidad de uso de la plataforma y de acceso a los servicios.
                            </li>
                            <li>
                                el costo de obtención de productos o servicios sustitutos.
                            </li>
                            <li>
                                fallos que pudieran producirse en las comunicaciones, incluido el borrado, transmisión
                                incompleta o retrasos en la remisión, no comprometiéndose tampoco a que la red de
                                transmisión esté operativa en todo momento.
                            </li>
                            <li>
                                el acceso no autorizado quebrantando las medidas de seguridad establecidas por E-Cripto
                                FX y la alteración o distribución del contenido que usted envía a través de la
                                plataforma, o el acceso a los mensajes o la remisión de virus informáticos.
                            </li>
                            <li>
                                el contenido de terceros puesto a su disposición a través de la plataforma.
                            </li>
                            <li>
                                cualquier otro asunto relacionado con algún aspecto de la plataforma y el servicio,
                                incluido el sitio web, cualquier aplicación actual o futura, las comunicaciones por
                                correo electrónico y el contenido de E-Cripto FX en sitios de terceros.
                            </li>
                        </ul>
                        Aceptas que, aunque hacemos todo lo posible para evitar que suceda, E-Cripto FX no puede ser
                        considerado responsable por el mal uso o abuso de cualquier imagen o del contenido publicado en
                        E-Cripto FX.
                        <br>
                        El usuario reconoce expresamente que asume toda la responsabilidad relacionada con los riesgos
                        de la seguridad, privacidad y confidencialidad inherentes al envío de cualquier contenido a
                        través de Internet. Por su propia naturaleza, Internet y las páginas web no pueden protegerse de
                        manera absoluta de intentos de intromisión maliciosa o intencionada.
                        <br>
                        E-Cripto FX no controla los sitios de terceros ni de internet a través de los cuales decida
                        enviar información personal confidencial u otro contenido y, por ende, E-Cripto FX no asume
                        ninguna garantía frente a interceptaciones o compromisos con respecto a su información.
                        <br>
                        E-Cripto FX |ha adoptado todas las medidas de seguridad legalmente exigidas para la protección
                        de los datos y la información del usuario. No obstante, E-Cripto FX no puede
                        garantizar la invulnerabilidad absoluta de sus sistemas de seguridad, ni puede garantizar la @
                        seguridad o inviolabilidad de dichos datos en su transmisión a través de la red.
                    </p>
                    <h6>Enlaces externos</h6>
                    <p>
                        Los enlaces a sitios externos que E-Cripto FX pone a disposición de los usuarios tienen por
                        único objeto facilitar a los mismos la búsqueda de la información disponible en Internet.
                        E-Cripto FX no ofrece ni comercializa los productos y servicios disponibles en los sitios
                        enlazados ni asume responsabilidad alguna por tales productos o servicios.
                        <br>
                        E-Cripto FX no se hace responsable del contenido de los sitios web a los que el usuario pueda
                        acceder a través de los enlaces establecidos en E-Cripto FX y declara que en ningún caso
                        procederá a examinar o ejercitar ningún tipo de control sobre el contenido de otros sitios de
                        Internet.
                    </p>
                    <h6>Derechos</h6>
                    <p>
                        Nos reservamos todos los derechos que no te hayamos cedido de forma expresa.
                        <br>
                        No puede transferir ninguno de sus derechos u obligaciones en virtud de este acuerdo sin nuestro
                        consentimiento.
                        <br>
                        Nuestros derechos y obligaciones pueden asignarse a otras partes, por ejemplo, en caso de
                        producirse un cambio de titularidad (es decir, si se efectúa una fusión, adquisición o venta de
                        activos) o si la Iey así lo exige.

                    </p>
                </small>
            </div>
            <div class="tab-pane fade {{($tipo == 'privacidad') ? 'show active' : ''}}" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                <h5 class="text-alt-gray">
                    <strong>Privacidad</strong>
                </h5>
                <small class="text-justify text-alt-gray">
                    <p>
                        Le informamos que cuando se da de alta en E-Cripto FX los datos que nos proporcione rellenando
                        cualquiera de los formularios de registro electrónico que aparece en esta página se recogerán en
                        ficheros para su tratamiento.
                        <br>
                        En cualquier momento usted podrá ejercer sus derechos de acceso, rectificación, cancelación y
                        oposición, a través de su panel de administración.
                        <br>
                        La recogida de sus datos es de carácter personal, se hace con la finalidad del correcto
                        funcionamiento del servicio.
                        <br>
                        E-Cripto FX se compromete a tratar de una manera absolutamente confidencial sus datos de
                        carácter personal y a utilizarlos solo para las finalidades indicadas. Asi mismo le informamos
                        que E-Cripto FX tiene implantadas las medidas de seguridad de tipo técnico y organizativas
                        necesarias para garantizar la seguridad de sus datos de carácter personal y evitar la
                        alteración, la perdida y el tratamiento y/o accesos no autorizados, teniendo en cuenta el estado
                        de la tecnología, la naturaleza de los datos almacenados y los riesgos que están expuestos,
                        provenientes de la acción humana o del medio físico y natural.
                    </p>
                </small>
            </div>
        </div>
    </div>
</div>