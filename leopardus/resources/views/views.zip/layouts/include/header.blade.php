<div class="page-header navbar navbar-fixed-top">
  <!-- BEGIN HEADER INNER -->
  <div class="page-header-inner ">
    <!-- BEGIN LOGO -->
    <div class="top-menu visible-xs" style="float:left;">
      <ul class="nav navbar-nav ">
                <li class="dropdown dropdown-user dropdown-dark " style="display:flex; align-items:center;">
            <img src="{{(!empty(Auth::user()->icono_paquete)) ? asset('assets/'.Auth::user()->icono_paquete) : asset('assets/img/logo-light.png')}}" height="40" alt="{{Auth::user()->paquete}}">
          </li>
        <li class="dropdown dropdown-extended dropdown-notification dropdown-dark" id="header_notification_bar">
        @include('layouts.include.notifications')
        </li>
      </ul>
    </div>
    <div class="page-logo">
      <a href="{{ url('/') }}">
        <img src="{{ asset('assets/img/logo-light.png') }}" alt="logo" class="logo-default" /> </a>
      <div class="menu-toggler sidebar-toggler">
        <!-- DOC: Remove the above "hide" to enable the sidebar toggler button on header -->
      </div>
    </div>
    <!-- END LOGO -->
    <!-- BEGIN RESPONSIVE MENU TOGGLER -->
    <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
    <!-- END RESPONSIVE MENU TOGGLER -->
    <!-- BEGIN PAGE ACTIONS -->
    <!-- DOC: Remove "hide" class to enable the page header actions -->
    
    <!-- END PAGE ACTIONS -->
    <!-- BEGIN PAGE TOP -->
    <div class="page-top hidden-xs">
      <!-- BEGIN HEADER SEARCH BOX -->
      <!-- DOC: Apply "search-form-expanded" right after the "search-form" class to have half expanded search box -->

      <!-- END HEADER SEARCH BOX -->
      <!-- BEGIN TOP NAVIGATION MENU -->
      <div class="top-menu">
        <ul class="nav navbar-nav pull-right">
          <li class="dropdown dropdown-user dropdown-dark hidden-xs" style="display:flex; align-items:center;">
            <img src="{{(!empty(Auth::user()->icono_paquete)) ? asset('assets/'.Auth::user()->icono_paquete) : asset('assets/img/logo-light.png')}}" height="40" alt="{{Auth::user()->paquete}}">
          </li>
          <li class="separator hide"> </li>
          <!-- BEGIN NOTIFICATION DROPDOWN -->
          <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
          <li class="dropdown dropdown-extended dropdown-dark hidden-xs" id="header_notification_bar">
          {{-- <li class="dropdown dropdown-extended dropdown-notification dropdown-dark" id="header_notification_bar"> --}}
            {{-- notificaciones --}}
          @include('layouts.include.notifications')
          </li>

          <li class="dropdown dropdown-extended dropdown-dark hidden-xs">
            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
              <span class="username"> {{ Auth::user()->display_name }} </span>
              </a>
            <ul class="dropdown-menu dropdown-menu-default">
            <li>
                <a href="{{ route('admin.user.edit') }}">
                    <i class="icon-settings"></i> Profile Edit </a>

              </li>
              <li>
                <a href="{{ route('logout') }}"
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <i class="icon-key"></i> Logout </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    {{ csrf_field() }}
                </form>
              </li>

            </ul>
          </li>

          <!-- END QUICK SIDEBAR TOGGLER -->
        </ul>
      </div>
      <!-- END TOP NAVIGATION MENU -->
    </div>
    <!-- END PAGE TOP -->
  </div>
  <!-- END HEADER INNER -->
</div>
