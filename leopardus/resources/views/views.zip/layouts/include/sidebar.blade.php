@php
$permiso = DB::table('settingpermiso')->where('iduser', Auth::user()->ID)->get();
$cliente = DB::table('settingcliente')->where('id', 1)->get();
$letras = ['A', 'B', 'C', 'D', 'E', 'F'];
@endphp
<div class="page-sidebar-wrapper">
    <!-- BEGIN SIDEBAR -->
    <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
    <!-- DOC: Change data-auto-speed="200" to adjust the sub menu slide up/down speed -->
    <div class="page-sidebar navbar-collapse collapse">
        <!-- BEGIN SIDEBAR MENU -->
        <!-- DOC: Apply "page-sidebar-menu-light" class right after "page-sidebar-menu" to enable light sidebar menu style(without borders) -->
        <!-- DOC: Apply "page-sidebar-menu-hover-submenu" class right after "page-sidebar-menu" to enable hoverable(hover vs accordion) sub menu mode -->
        <!-- DOC: Apply "page-sidebar-menu-closed" class right after "page-sidebar-menu" to collapse("page-sidebar-closed" class must be applied to the body element) the sidebar sub menu mode -->
        <!-- DOC: Set data-auto-scroll="false" to disable the sidebar from auto scrolling/focusing -->
        <!-- DOC: Set data-keep-expand="true" to keep the submenues expanded -->
        <!-- DOC: Set data-auto-speed="200" to adjust the sub menu slide up/down speed -->
        <ul class="page-sidebar-menu" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
            {{-- INICIO --}}
            <li class="nav-item">
                <a href="{{url('admin')}}" class="nav-link nav-toggle">
                    <i class="fas fa-home"></i>
                    <span class="title">Inicio</span>
                </a>
            </li>
            {{-- <li class="nav-item">
                <a href="{{url('admin/updateall')}}" class="nav-link nav-toggle">
                    <i class="fas fa-sync-alt"></i>
                    <span class="title">Actualizar</span>
                </a>
            </li> --}}
            <li class="nav-item">
                <a href="javascript:;" class="nav-link nav-toggle" data-toggle="modal" data-target="#myModal">
                    <i class="fas fa-percentage"></i>
                    <span class="title">Rentabilidad</span>
                </a>
            </li>
            @if ($permiso[0]->nuevo_registro == 1)
            <li class="nav-item">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fas fa-user-plus"></i>
                    <span class="title">Registrar</span>
                    <span class="arrow"></span>
                    <ul class="sub-menu">
                        <li class="nav-item">
                            <a href="{{route('autenticacion.new-register').'?referred_id='.Auth::user()->ID.'&lado=D'}}"
                                class="nav-link">
                                <span class="title">Nuevo Usuario Derecha</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{route('autenticacion.new-register').'?referred_id='.Auth::user()->ID.'&lado=I'}}"
                                class="nav-link">
                                <span class="title">Nuevo Usuario Izquierda</span>
                            </a>
                        </li>
                    </ul>
                </a>
            </li>
            @if ($cliente[0]->cliente == 1)
            <li class="nav-item">
                <a href="{{url('autentication/register')}}?referred_id={{ Auth::user()->ID }}&tipouser=Cliente"
                    class="nav-link nav-toggle">
                    <i class="fas fa-user-plus"></i>
                    <span class="title">Nuevo Registro Cliente</span>
                </a>
            </li>
            @endif
            @endif
            {{-- FIN INICIO --}}
            {{-- @if (Auth::user()->ID == 1) --}}
            {{-- GEONOLOGIA --}}
            @if ($permiso[0]->red_usuario == 1)
            <li class="nav-item">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fas fa-sitemap"></i>
                    <span class="title">Red de Usuarios</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item">
                        <a href="{{url('referraltree')}}" class="nav-link">
                            <span class="title">Árbol de Usuarios</span>
                        </a>
                    </li>
                    @if ($cliente[0]->cliente == 1)
                    <li class="nav-item">
                        <a href="{{url('referraltree')}}?user=Cliente" class="nav-link">
                            <span class="title">Árbol de Clientes</span>
                        </a>
                    </li>
                    @endif
                    <li class="nav-item">
                        <a href="{{url('admin/network/directrecords')}}" class="nav-link">
                            <span class="title">Lista de Directos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/network/networkrecords')}}" class="nav-link">
                            <span class="title">Usuarios en Red</span>
                        </a>
                    </li>
                </ul>
            </li>
            {{-- Tablero --}}
            {{-- <li class="nav-item">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="fas fa-chess-board"></i>
                    <span class="title">Tableros de Usuarios</span>
                    <span class="arrow"></span>
                </a>
                <ul class="sub-menu">
                    @foreach ($letras as $letra)
                    <li class="nav-item">
                        <a href="{{url('referraltree/tablero/'.$letra)}}" class="nav-link">
            <span class="title">Tablero {{$letra}}</span>
            </a>
            </li>
            @endforeach
        </ul>
        </li> --}}
        @endif
        {{-- FIN GENEALOGIA --}}
        {{-- TRANSACCIONES --}}
        <li class="nav-item">
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="far fa-money-bill-alt"></i>
                <span class="title">Transacciones</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item">
                    <a href="{{url('admin/transactions/networkorders')}}" class="nav-link">
                        <span class="title">Ordenes de Red</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{url('admin/transactions/personalorders')}}" class="nav-link">
                        <span class="title">Ordenes Personales</span>
                    </a>
                </li>
            </ul>
        </li>
        {{--FIN TRANSACCIONES --}}
        {{-- VISION DE USUARIO --}}
        @if ($permiso[0]->vision_usuario == 1)
        <li>
            <a href="{{url('admin/buscar')}}" class="nav-link nav-toggle">
                <i class="far fa-id-badge"></i>
                <span class="title">Search user</span>
            </a>
        </li>
        @endif
        {{-- FIN VISION DE USUARIO --}}

        {{-- LISTA DE USUARIOS--}}
        @if ($permiso[0]->vision_usuario == 1)
        <li>
            <a href="{{url('admin/userrecords')}}" class="nav-link nav-toggle">
                <i class="fas fa-list"></i>
                <span class="title">Lista de Usuarios</span>
            </a>
        </li>
        @endif
        {{-- FIN LISTA DE USUARIOS --}}

        {{-- BILLETERA --}}
        @if ($permiso[0]->billetera == 1)
        {{-- <li>
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fas fa-wallet"></i>
                <span class="title">E-wallet</span>
                <span class="arrow"></span>
                <ul class="sub-menu">
                    <li class="nav-item">
                        <a href="{{url('admin/wallet')}}" class="nav-link">
        <span class="title">Cash</span>
        </a>
        </li>
        <li class="nav-item">
            <a href="{{url('admin/wallet/tantechcoins')}}" class="nav-link">
                <span class="title">Tantech</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{url('admin/wallet/puntos')}}" class="nav-link">
                <span class="title">Puntos</span>
            </a>
        </li>
        </ul>
        </a>
        </li> --}}
        @endif
        {{-- FIN BILLETERA --}}
        {{-- PAGO --}}
        @if ($permiso[0]->pago == 1)
        <li>
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fas fa-money-check-alt"></i>
                <span class="title">Retiros</span>
                <span class="arrow"></span>
                <ul class="sub-menu">
                    <li class="nav-item">
                        <a href="{{url('admin/price/historial')}}" class="nav-link">
                            <span class="title">Historial de Retiro</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/price/confirmar')}}" class="nav-link">
                            <span class="title">Confirmar Pagos</span>
                        </a>
                    </li>
                    {{-- <li class="nav-item">
                        <a href="{{url('admin/price/confirmados')}}" class="nav-link">
                    <span class="title">Ingresos liberados</span>
            </a>
        </li> --}}
        </ul>
        </a>
        </li>
        @endif
        {{-- FIN PAGO --}}
        {{-- INFORMES --}}
        @if ($permiso[0]->informes == 1)
        <li>
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fas fa-chart-bar"></i>
                <span class="title">Reportes</span>
                <span class="arrow"></span>
                <ul class="sub-menu">
                    <li class="nav-item">
                        <a href="{{route('info.list-rango')}}" class="nav-link">
                            <span class="title">Usuario Rangos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                            <a href="{{url('admin/info/debito/todo/comisioncompra')}}" class="nav-link">
                                <span class="title">Balance Cash</span>
                            </a>
                        </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/debito/ingreso/comisioncompra')}}" class="nav-link">
                            <span class="title">Ingreso Cash</span>
                        </a>
                    </li>
                    <li class="nav-item">
                            <a href="{{url('admin/info/debito/egreso/comisioncompra')}}" class="nav-link">
                                <span class="title">Egreso Cash</span>
                            </a>
                        </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/puntos/egreso/comisioncompra')}}" class="nav-link">
                            <span class="title">Balance Coins</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/billeteras')}}" class="nav-link">
                            <span class="title">Total Billeteras</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/perfil')}}" class="nav-link">
                            <span class="title">Perfil</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/ventas')}}" class="nav-link">
                            <span class="title">Ventas</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/rango')}}" class="nav-link">
                            <span class="title">Rangos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/pagos')}}" class="nav-link">
                            <span class="title">Pagos</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{url('admin/info/feed')}}" class="nav-link">
                            <span class="title">Descuentos</span>
                        </a>
                    </li>
                    {{-- <li class="nav-item">
                        <a href="{{url('admin/info/reportes')}}" class="nav-link">
                    <span class="title">Reportes pagos</span>
            </a>
        </li> --}}
        <li class="nav-item">
            <a href="{{url('admin/info/comisiones')}}" class="nav-link">
                <span class="title">Comisiones</span>
            </a>
        </li>
        {{-- <li class="nav-item">
                        <a href="{{url('admin/info/repor-comi')}}" class="nav-link">
        <span class="title">Reportes Comisiones</span>
        </a>
        </li> --}}
        </ul>
        </a>
        </li>
        @endif
        {{-- FIN GESTION DE PERFILES --}}
        {{-- INICIO TICKETS --}}
        @if ($permiso[0]->tickets == 1)
        <li class="nav-item">
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fas fa-users-cog"></i>
                <span class="title">Tickets</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item">
                    <a href="{{url('admin/ticket/todosticket')}}" class="nav-link">
                        <span class="title">Todos los Tickets</span>
                    </a>
                </li>
            </ul>
        </li>
        @endif
        {{-- FIN TICKETS --}}
        {{-- BUZON --}}
        @if ($permiso[0]->buzon == 1)
        {{-- <li>
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="far fa-envelope"></i>
                    <span class="title">Buzon</span>
                </a>
            </li> --}}
        @endif
        {{-- FIN BUZON --}}
        {{-- RANKING --}}
        @if ($permiso[0]->ranking == 1)

        @endif
        {{--FIN RANKING --}}
        {{-- HISTORIAL DE ACTIVIDAD --}}
        @if ($permiso[0]->historial_actividades == 1)
        <li>
            <a href="{{url('admin/actividad/actividad')}}" class="nav-link nav-toggle">
                <i class="fas fa-history"></i>
                <span class="title">Historial de Actividad</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{url('admin/ranking')}}" class="nav-link nav-toggle">
                <i class="fas fa-globe"></i>
                <span class="title">Lideres</span>
            </a>
        </li>
        @endif
        {{-- FIN HISTORIAL DE ACTIVIDAD --}}
        {{-- EMAIL MARKETING --}}
        @if ($permiso[0]->email_marketing == 1)

        @endif
        {{-- FIN EMAIL MARKETING --}}
        {{-- ADMINISTRAR REDES --}}
        @if ($permiso[0]->administrar_redes == 1)

        @endif
        {{-- FIN ADMINISTRAR REDES --}}
        {{-- SOPORTE --}}
        @if ($permiso[0]->soporte == 1)

        @endif
        {{-- FIN SOPORTE --}}
        {{-- INICIO TIENDA INTERNA --}}
        @if ($permiso[0]->tickets == 1)
        <li class="nav-item">
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fas fa-briefcase"></i>
                <span class="title">E-commerce</span>
                <span class="arrow"></span>
            </a>
            <ul class="sub-menu">
                <li class="nav-item">
                    <a href="{{url('tienda')}}" class="nav-link">
                        <span class="title">Productos</span>
                    </a>
                </li>
                {{-- <li class="nav-item">
                    <a href="{{url('tienda/solicitudes')}}" class="nav-link">
                <span class="title">Solicitudes Compra</span>
                </a>
        </li> --}}
        </ul>
        </li>
        @endif
        {{-- FIN TIENDA INTERNA --}}
        {{-- AJUSTES --}}
        @if ($permiso[0]->ajuste == 1)
        @endif
        {{-- FIN AJUSTES --}}
        {{-- HERRAMIENTAS --}}
        @if ($permiso[0]->herramienta == 1)
        <li>
            <a href="javascript:;" class="nav-link nav-toggle">
                <i class="fas fa-wrench"></i>
                <span class="title">Herramientas</span>
                <span class="arrow"></span>
                <ul class="sub-menu" style="display: none;">
                    <li class="nav-item">
                        <a href="{{url('admin/archivo/ver')}}" class="nav-link">
                            <span class="title">Materiales</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{url('admin/archivo/contenido')}}" class="nav-link">
                            <span class="title">Gestion de Noticias</span>
                        </a>
                    </li>
                </ul>
            </a>
        </li>
        @endif
        {{-- FIN HERRAMIENTAS --}}
        {{-- <li class="nav-item">
            <a href="{{route('settings.reset')}}" class="nav-link nav-toggle">
        <i class="fas fa-undo"></i>
        <span class="title">Reinicio del Sistema</span>
        </a>
        </li> --}}
        <li class="nav-item">
            <a href="{{ route('admin.user.edit') }}" class="nav-link nav-toggle">
                <i class="icon-settings"></i>
                <span class="title">Editar Perfil</span>
            </a>

        </li>
        {{-- CERRAR SESIÓN --}}
        <li class="nav-item">
            <a href="{{ route('logout') }}"
                onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span class="title">Cerrar Sesión</span>
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
        </li>
        {{-- FIN CERRAR SESIÓN --}}
        {{-- @else

            @endif --}}
        </ul>
    </div>
</div>