@php
$notificaciones = [];
	$notificaciones = DB::table('notificaciones')
							->where([
								['iduser', '=', Auth::user()->ID],
								['vista', '=', 0]
							])->get();
@endphp


   <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
      <i class="icon-bell"></i>
        @if (count($notificaciones) != 0)
		<span class="badge badge-success"> {{ count($notificaciones) }} </span>
		@endif
   </a>
   <ul class="dropdown-menu">
      <li class="external">
         <h3>{{ count($notificaciones) }} Notificaciones Pendientes</h3>
         {{-- <a href="{{route('admin.notifications')}}">Ver Todas</a> --}}
      </li>
      <li>
         <ul class="dropdown-menu-list scroller" style="height: 250px;" data-handle-color="#637283">
            @foreach ($notificaciones as $notificacion)
			   {{-- @if ($notificacion->status == 0) 
			   <li style="background-color: #637283;"> 
				@else  --}}
				{{-- @endif --}}
					<li> 
	               <a href="{{ url($notificacion->ruta) }}">
	                  <span class="time">{{ date('d-m-Y', strtotime($notificacion->created_at)) }}</span>
	                  <span class="details">
	                     <span class="label label-sm label-icon">
							<i class="{{ $notificacion->icono }}"></i>
							{{ $notificacion->titulo }}
	                     </span>
	                     {{ $notificacion->descripcion }}
	                  </span>
	               </a>
	            </li>
	         @endforeach
         </ul>
      </li>
   </ul>
